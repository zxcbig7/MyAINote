﻿using System;
using System.Data;
using System.IO;

namespace CSV_test
{
    class Program
    {
        static void Main(string[] args)
        {
            string filename = @"C:\Users\zxcbig7\Desktop\CSV\CSV test\bin\Debug\net5.0\testdata.csv";
            FileStream fileStream = new FileStream(filename, FileMode.Open, FileAccess.Read);
            try
            {
                // read from file or write to file
            }
            finally
            {
                fileStream.Close();
            }
        }

        // [ DataTable 數 據 寫 入 CSV 文 件 ]
        internal static void SaveCSV(DataTable dt, string filePath)
        {
            FileInfo fi = new FileInfo(filePath);
            
            if (!fi.Directory.Exists) fi.Directory.Create();

            FileStream fs = new FileStream(filePath, FileMode.Create, FileAccess.Write);

            StreamWriter sw = new StreamWriter(fs, System.Text.Encoding.UTF8);

            string data = "";

            // 寫Column Name
            for (int i = 0; i < dt.Columns.Count; i++)
            {
                data += dt.Columns[i].ColumnName.ToString();
                if (i < dt.Columns.Count - 1) data += ',';
            }
            sw.WriteLine(data);

            // 寫Row data
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                data = "";
                for (int j = 0; j < dt.Columns.Count; j++)
                {
                    string str = dt.Rows[i][j].ToString();
                    str = str.Replace("\"", "\"\""); //替换英文冒号 英文冒号需要换成两个冒
                
                    if (str.Contains(',') || str.Contains('"') || str.Contains('\r') || str.Contains('\n')) //含逗號 冒號 換行符號的需要放到引號中
                    {
                        str = string.Format("\"{0}\"", str);
                    }

                    data += str;

                    if (j < dt.Columns.Count - 1)
                    {
                        data += ",";
                    }
                }
                sw.WriteLine(data);
            }
            sw.Close();
            fs.Close();
        }

        // [ 讀 取 CSV 到 DataTable ]
        internal static DataTable OpenCSV(String filePath)
        {
            DataTable dt = new DataTable();

            FileStream fs = new FileStream(filePath, FileMode.Open, FileAccess.Read);

            StreamReader sr = new StreamReader(fs);

            string strLine = ""; // 讀取一行紀錄

            // 記錄每行中的各字段內容
            string[] aryLine = null;
            string[] tableHead = null;

            // 標示序列
            int columnCount = 0;

            // 判斷是否為第一行
            bool IsFirst = true;


            while ((strLine = sr.ReadLine()) != null)
            {
                if (IsFirst == true)
                {
                    tableHead = strLine.Split(','); //資料用「,」分隔
                    IsFirst = false;
                    columnCount = tableHead.Length;
                    for (int i = 0; i < columnCount; i++)
                    {
                        DataColumn dc = new DataColumn(tableHead[i]);
                        dt.Columns.Add(dc);
                    }
                }
                else
                {
                    aryLine = strLine.Split(',');
                    DataRow dr = dt.NewRow();
                    for (int j = 0; j < columnCount; j++)
                    {
                        dr[j] = aryLine[j];
                    }
                    dt.Rows.Add(dr);
                }
            }
            if (aryLine != null && aryLine.Length > 0)
            {
                dt.DefaultView.Sort = tableHead[0] + " " + "asc";
            }

            sr.Close();
            fs.Close();

            return dt;
        }

        // [ 修 改 文 件 名 稱 ]
        // 需要保存歷史數據或者知道那個文件被修改 可以通過蓋變文件的名稱 如加上當天的日期等等。
        internal static bool ChangeFileName(string OldPath, string NewPath)
        {
            bool re = false;
            try
            {
                if (File.Exists(OldPath))
                {
                    File.Move(OldPath, NewPath);
                    re = true;
                }
            }
            catch
            {
                re = false;
            }
            return re;
        }

        // [ CSV 文 件 的 數 據 寫 入 ]
        // 直接在網頁表單提交數據保存在csv文件中 直接寫入文件
        internal static bool SaveCSV(string fullPath, string Data)
        {
            bool re = true;
            try
            {
                FileStream FileStream = new FileStream(fullPath, FileMode.Append);
                StreamWriter sw = new StreamWriter(FileStream, System.Text.Encoding.UTF8);
                sw.WriteLine(Data);
                //清空缓冲区
                sw.Flush();
                //关闭流
                sw.Close();
                FileStream.Close();
            }
            catch
            {
                re = false;
            }
            return re;
        }


        // [ 取得檔案資訊]
        internal static void GetFileInfo(string filePath)
        {
            FileInfo myInfo = new FileInfo(filePath);
            //判斷檔案是否存在
            if (myInfo.Exists)
            {
                //輸出檔名
                Console.WriteLine("FileName:{0}", myInfo.Name);
                //輸出路徑
                Console.WriteLine("Path:{0}", myInfo.FullName);
            }
        }

        // [ 複 製 檔 案 ]
        internal static void CopyFile(string filePathFrom,string filePathTo)
        {
            //引用類別
            FileInfo myInfo = new FileInfo(filePathFrom);
            //判斷檔案是否存在
            if (myInfo.Exists)
            {
                //複製檔案
                myInfo.CopyTo(filePathTo);
            }
        }

        // [ 變 更 檔 名 ]
        internal static void ChanegeFileName(string filePathFrom, string filePathTo)
        {
            //引用類別
            FileInfo myInfo = new FileInfo(filePathFrom);
            //判斷檔案是否存在
            if (myInfo.Exists)
            {
                myInfo.CopyTo(filePathTo); //複製檔案
            }
            myInfo.Delete();
        }
    }
}
